/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import dao.ClienteDao;
import entity.Cliente;
import entity.Distrito;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Alumno
 */ 
 @Repository
public class ClienteDaoImpl implements ClienteDao {
 
     private JdbcTemplate jdbcTemplate;
     
     @Autowired
     private void setDataSource(DataSource dataSource){
       this.jdbcTemplate = new JdbcTemplate(dataSource);
     }
     
    @Override
    public void registrar(Cliente  cliente) {
        String sql = "INSERT INTO tb_cliente(cli_nom,cli_dir,dis_id) VALUES(?,?,?)";
        Object param[] = {cliente.getNombre(),cliente.getDireccion(),cliente.getDistrito().getId()};
       this.jdbcTemplate.update(sql,param);
       
       
    }

    @Override
    public List<Cliente> consultarPorNombre(String nombre) {
    List<Cliente> listaCliente = new ArrayList<>();        
        String sql = "SELECT c.cli_id, c.cli_nom, c.cli_dir,"
                + " d.dis_id, d.dis_nom FROM tb_cliente c, tb_distrito d "
                + " WHERE c.dis_id=d.dis_id  AND c.cli_nom LIKE ?";
        
        Object param[] = {nombre + "%"};
       
        List<Map<String,Object>> lista = this.jdbcTemplate.queryForList(sql, param);
        
        for(Map<String, Object> map:lista){
            Cliente cliente = new Cliente();
            cliente.setId(Integer.parseInt(map.get("cli_id").toString()));
            cliente.setNombre(map.get("cli_nom").toString());
            cliente.setDireccion(map.get("cli_dir").toString());
            Distrito distrito = new Distrito();
            distrito.setId(Integer.parseInt(map.get("dis_id").toString()));
            distrito.setNombre(map.get("dis_nom").toString());
            cliente.setDistrito(distrito);
            
            listaCliente.add(cliente);
        }
               
        return listaCliente;
    }
    
}
