/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service.impl;
import entity.Cliente;
import dao.ClienteDao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import service.ClienteService;
import org.springframework.stereotype.Service;
/**
 *
 * @author Alumno
 */
@Service(value="clienteService")
public class ClienteServiceImpl implements ClienteService {

   // private ClienteDao clienteDao = new ClienteDAO(); //NO SE DEBE HACER
    
    @Autowired
    private ClienteDao clienteDao;
    
    
    
    @Override
    public void registrar(Cliente cliente) {
      clienteDao.registrar(cliente);//
    }

    @Override
    public List<Cliente> consultarPorNombre(String nombre) {
     return clienteDao.consultarPorNombre(nombre);
    }
    
}
