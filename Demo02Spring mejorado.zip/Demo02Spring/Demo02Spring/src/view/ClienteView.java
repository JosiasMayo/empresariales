/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import dao.ClienteDao;
import dao.impl.ClienteDaoImpl;
import entity.Cliente;
import entity.Distrito;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import service.ClienteService;
import service.impl.ClienteServiceImpl;

 
public class ClienteView {
     
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("META-INF/spring.xml");
        ClienteService clienteService= 
                 ctx.getBean("clienteService",ClienteService.class); // 
        
     /*   Cliente cliente = new Cliente();
       
        cliente.setNombre("ANA");
        cliente.setDireccion("jr maestro peruano");
        
        Distrito distrito = new Distrito();
        distrito.setId(1);
        distrito.setNombre("Comas");
        cliente.setDistrito(distrito);
        
        clienteService.registrar(cliente);*/
        
         List<Cliente> listaCliente = clienteService.consultarPorNombre("");
        for(Cliente cliente:listaCliente){
            System.out.println(cliente.getId() + " - " +
                        cliente.getNombre() + " - " +
                        cliente.getDistrito().getNombre());
                    
        }
        
    }
    
}
