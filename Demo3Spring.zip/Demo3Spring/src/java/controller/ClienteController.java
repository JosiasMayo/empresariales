/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Alumno
 */
@Controller
public class ClienteController {
    
    @RequestMapping("clienteAbrir.htm")
    public String clienteAbrir(){  
      
      return "cliente-nuevo";
    }
    
     @RequestMapping("clienteNuevo.htm")
    public String clienteNuevo(
          @RequestParam(value="txtNombre") String nombre,
                 @RequestParam(value="txtDireccion") String direccion,
                          @RequestParam(value="cboDistrito") Integer idDistrito,
                         Model model
                          
                          ){
        model.addAttribute("mensaje","cliente guardado!");
                          System.out.println(nombre + "-" + direccion + "-" + idDistrito);
                                  return "cliente-nuevo";
    }
}
